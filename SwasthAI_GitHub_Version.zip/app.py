
import streamlit as st

st.set_page_config(page_title="SwasthAI", layout="centered")

st.title("🩺 SwasthAI - Har Ghar Ek Doctor")
st.write("Diagnose common health issues like fever, diabetes, and cold using AI.")

symptom = st.text_input("Enter your symptoms (in Hindi or English):")

if symptom:
    if "fever" in symptom.lower():
        st.warning("You may have a viral fever. Stay hydrated and rest. If symptoms persist, consult a real doctor.")
    elif "sugar" in symptom.lower() or "diabetes" in symptom.lower():
        st.info("Diabetes symptoms detected. Please monitor blood sugar levels and consult a physician.")
    elif "cold" in symptom.lower():
        st.success("It seems like common cold. Take steam and rest.")
    else:
        st.write("Sorry, we couldn't detect specific diagnosis. Try describing symptoms more clearly.")

st.markdown("---")
st.caption("SwasthAI is for educational purposes only and does not replace medical advice.")
