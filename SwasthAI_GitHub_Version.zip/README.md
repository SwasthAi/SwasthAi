
# SwasthAI

🩺 Your AI-Powered Digital Doctor — Fever, Diabetes & Cold Diagnosis from Home!

## Features:
- Symptom checker for fever, diabetes, cold (basic level)
- Supports Hindi & English
- Web interface built with Streamlit
- Android app (WebView)
- Free & accessible to everyone

## How to Run:
1. Install Streamlit: `pip install streamlit`
2. Run app: `streamlit run app.py`

## License:
This project is open source under the MIT License.
